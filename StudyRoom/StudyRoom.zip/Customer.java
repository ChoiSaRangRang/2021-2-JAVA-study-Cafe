import java.util.Calendar;

public class Customer extends Person {
	private int seatID;
	private long startTime;
	private long endTime;
	Calendar cal=Calendar.getInstance();
	
	public Customer(){
		
	}
	public Customer(String name){
		super(name);
	}
	public int getSeatID() {
		return seatID;
	}

	public void setSeatID(int seatID) {
		this.seatID = seatID;
	}
	
	public void setstartTime(long startTime) {
		this.startTime = startTime; 
	}
	
	public long getstartTime() {
		return startTime;
	}
	
	public void setendTime(long endTime) {
		this.endTime = endTime;
		endTime=cal.get(Calendar.MINUTE);
	}
	
	public long getendTime() {
		return endTime;
	}
	
}
