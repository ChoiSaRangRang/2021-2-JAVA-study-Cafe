import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {
	public static void main(String[] args) {
		Management mngment = new Management();
		int selectNo = 0;

		Scanner scan = new Scanner(System.in);
		scan = new Scanner(System.in);

		while (true) {
			selectNo = 0;
			System.out.println("[LaLaLa StudyRoom]");
			System.out.println("1.����");
			System.out.println("2.����");
			System.out.println("3.������");
			System.out.println("4.����");
			System.out.print("-->");

			try {
				selectNo = scan.nextInt();
				if (1 <= selectNo && selectNo <= 4) {
					if (selectNo == 1) {
						mngment.setIn();
					} else if (selectNo == 2) {
						mngment.setOut();
					} else if (selectNo == 3) {
						mngment.admin();
					} else if (selectNo == 4) {
						System.out.println();
						System.out.println("���α׷��� ����˴ϴ�.");
						break;
					}
				} else {
					System.out.println("�߸� �Է��ϼ̽��ϴ�.");
					System.out.println();
				}
			} catch (InputMismatchException e) {
				scan.nextLine();
				System.out.println("�ٸ� ���ڸ� �Է��߽��ϴ�.");
				System.out.println();
				continue;
			}

		}
	}
}
