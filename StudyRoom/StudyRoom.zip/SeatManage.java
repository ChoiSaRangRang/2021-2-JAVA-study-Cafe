import java.util.Arrays;

public class SeatManage {
	
	private boolean [][] setTable = new  boolean[2][5];
	
	public SeatManage() {
		for(int i=0;i<2;i++) {
			for(int j=0;j<5;j++) {
			setTable[i][j]=false;	
			}
		}
	}
	public void clear() {
		for(int i=0;i<2;i++) {
			for(int j=0;j<5;j++) {
			setTable[i][j]=false;	
			}
		}
	}
	public void print() {
		for(int i=0; i<2;i++) {
			for(int j=0;j<5;j++) {
				if(setTable[i][j]==true)
					System.out.print("C["+(i+1)+(j+1)+"]	");
				else
					System.out.print("V["+(i+1)+(j+1)+"]	");	
			}
			System.out.println();
		}
		
	}
	public void setSeat(int x, int y) {
		if(setTable[x][y]==true) {
			System.out.println("�̹� ��� �� �Դϴ�.");
			System.out.println();
		}
		else {
			setTable[x][y]=true;
		}
		
	}
	public void releaseSeat(int x, int y) {
		if(setTable[x][y]==true) {
			setTable[x][y]=false;
		}
	}
	public int countSeat() {
		int count=0;
		for(int i=0;i<2;i++) {
			for(int j=0;j<5;j++) {
				if(setTable[i][j]==false) {
					count++;
			}
		}
	}
		return count;
	}
	public boolean isSeat(int x, int y) {
		if(setTable[x][y]==true) {
			return true;
		}
		else
			return false;
	}
	

}

	

